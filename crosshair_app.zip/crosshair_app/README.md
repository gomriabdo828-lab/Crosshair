# 🎯 Crosshair — احترافي لأندرويد

تطبيق crosshair overlay احترافي، يعمل فوق أي تطبيق أو لعبة،
بنفس أسلوب RedMagic Game Space.

---

## ✅ المميزات

| ميزة | التفاصيل |
|---|---|
| 5 أشكال | CROSS · DOT · CIRCLE · T_SHAPE · X_SHAPE |
| ألوان حرة | Hex picker لكل من crosshair + outline |
| حجم وسماكة وفجوة | sliders كاملة |
| نقطة مركزية | قابلة للتعديل |
| Outline مستقل | سماكة + لون |
| Opacity | شفافية كاملة 0→1 |
| Presets | حفظ وتحميل إعدادات مخصصة |
| Overlay دائم | Foreground Service — يبقى مفعّل أثناء الألعاب |
| تصميم داكن | نفس أسلوب RedMagic / ASUS ROG |

---

## 🔨 البناء من GitHub

### 1. رفع المشروع على GitHub

```bash
# في مجلد المشروع
git init
git add .
git commit -m "init: crosshair app"

# أنشئ repo جديد على github.com ثم:
git remote add origin https://github.com/YOUR_USERNAME/crosshair.git
git branch -M main
git push -u origin main
```

### 2. البناء اليدوي (Android Studio)

```
1. افتح Android Studio
2. File → Open → اختر مجلد crosshair_app
3. انتظر Gradle sync (دقيقة تقريباً)
4. Build → Build Bundle(s) / APK(s) → Build APK(s)
5. الملف يكون في: app/build/outputs/apk/debug/app-debug.apk
```

### 3. البناء التلقائي عبر GitHub Actions

بعد رفع الكود، كل push على فرع `main` يبني APK تلقائياً:

```
1. افتح صفحة الـ repo على GitHub
2. اضغط تبويب "Actions"
3. انتظر workflow "Android CI"
4. بعد الانتهاء → اضغط على الـ run → "Artifacts" → حمّل crosshair-debug.apk
```

### 4. البناء عبر Command Line (بدون Android Studio)

```bash
# تأكد أن ANDROID_HOME معرّف
export ANDROID_HOME=$HOME/Android/Sdk
export PATH=$PATH:$ANDROID_HOME/tools:$ANDROID_HOME/platform-tools

cd crosshair_app
chmod +x gradlew
./gradlew assembleDebug

# APK في:
# app/build/outputs/apk/debug/app-debug.apk
```

---

## 📲 التثبيت

```bash
adb install app/build/outputs/apk/debug/app-debug.apk
```

أو انقل الـ APK للجهاز وثبّته مباشرة (لازم تفعّل "Unknown Sources").

---

## ⚙️ أذونات مطلوبة

| إذن | السبب |
|---|---|
| `SYSTEM_ALERT_WINDOW` | رسم Overlay فوق كل شيء |
| `FOREGROUND_SERVICE` | الخدمة تبقى شغّالة أثناء الألعاب |
| `POST_NOTIFICATIONS` | إشعار الخدمة (Android 13+) |

عند أول تشغيل، التطبيق يطلب إذن **"Display over other apps"** — اقبله من الإعدادات.

---

## 🏗️ هيكل الملفات

```
crosshair_app/
├── app/src/main/
│   ├── java/com/noob/crosshair/
│   │   ├── CrosshairView.java     ← رسم الـ crosshair
│   │   ├── OverlayService.java    ← الـ foreground service
│   │   ├── MainActivity.java      ← واجهة التحكم
│   │   └── PrefsKeys.java         ← مفاتيح الإعدادات
│   ├── res/
│   │   ├── layout/activity_main.xml
│   │   ├── values/{colors,styles,strings}.xml
│   │   ├── drawable/{spinner_bg,swatch_bg}.xml
│   │   └── menu/main_menu.xml
│   └── AndroidManifest.xml
├── .github/workflows/build.yml    ← CI تلقائي
├── build.gradle
├── settings.gradle
└── README.md
```
