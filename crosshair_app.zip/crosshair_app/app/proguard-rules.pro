# Keep enum names for SharedPreferences lookups
-keepclassmembers enum com.noob.crosshair.CrosshairView$CrosshairStyle { *; }
-keep class com.noob.crosshair.** { *; }
