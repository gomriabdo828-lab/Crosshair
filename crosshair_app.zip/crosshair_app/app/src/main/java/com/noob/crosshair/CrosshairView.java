// Language: Java  |  File: CrosshairView.java  |  Target: Android API 26+
// Note: Custom View — draws the full crosshair on a transparent Canvas

package com.noob.crosshair;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.view.View;

public class CrosshairView extends View {

    // ── config ──────────────────────────────────────────────────────────────
    public enum CrosshairStyle { CROSS, DOT, CIRCLE, T_SHAPE, X_SHAPE }

    private CrosshairStyle style     = CrosshairStyle.CROSS;
    private int   color              = Color.RED;
    private float size               = 20f;   // half-arm length in dp
    private float thickness          = 2f;    // stroke width in dp
    private float gap                = 4f;    // center gap in dp
    private float dotRadius          = 2f;    // center dot radius in dp
    private boolean showDot          = true;
    private boolean showOutline      = true;
    private float outlineThickness   = 1f;
    private int   outlineColor       = Color.BLACK;
    private float opacity            = 1f;    // 0.0 – 1.0

    // ── paint objects ───────────────────────────────────────────────────────
    private final Paint linePaint    = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dotPaint     = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint outlinePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint erasePaint   = new Paint();

    private float density;

    // ── constructor ──────────────────────────────────────────────────────────
    public CrosshairView(Context ctx) {
        super(ctx);
        density = ctx.getResources().getDisplayMetrics().density;
        setWillNotDraw(false);
        setLayerType(LAYER_TYPE_HARDWARE, null);

        erasePaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
        erasePaint.setStyle(Paint.Style.FILL);

        refreshPaints();
    }

    // ── paint config ─────────────────────────────────────────────────────────
    private void refreshPaints() {
        int alpha = (int)(opacity * 255);

        linePaint.setColor(color);
        linePaint.setAlpha(alpha);
        linePaint.setStyle(Paint.Style.STROKE);
        linePaint.setStrokeWidth(dp(thickness));
        linePaint.setStrokeCap(Paint.Cap.ROUND);

        dotPaint.setColor(color);
        dotPaint.setAlpha(alpha);
        dotPaint.setStyle(Paint.Style.FILL);

        outlinePaint.setColor(outlineColor);
        outlinePaint.setAlpha(alpha);
        outlinePaint.setStyle(Paint.Style.STROKE);
        outlinePaint.setStrokeWidth(dp(thickness + outlineThickness * 2));
        outlinePaint.setStrokeCap(Paint.Cap.ROUND);
    }

    private float dp(float v) { return v * density; }

    // ── draw ─────────────────────────────────────────────────────────────────
    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float cx = getWidth()  / 2f;
        float cy = getHeight() / 2f;

        switch (style) {
            case CROSS:    drawCross(canvas, cx, cy, false); break;
            case DOT:      drawDotOnly(canvas, cx, cy);      break;
            case CIRCLE:   drawCircle(canvas, cx, cy);       break;
            case T_SHAPE:  drawT(canvas, cx, cy);            break;
            case X_SHAPE:  drawCross(canvas, cx, cy, true);  break;
        }

        if (showDot && style != CrosshairStyle.DOT) {
            if (showOutline)
                canvas.drawCircle(cx, cy, dp(dotRadius) + dp(outlineThickness), outlinePaint);
            canvas.drawCircle(cx, cy, dp(dotRadius), dotPaint);
        }
    }

    private void drawCross(Canvas c, float cx, float cy, boolean diagonal) {
        float arm  = dp(size);
        float gap_ = dp(gap);

        if (diagonal) {
            float d = (float)(gap_ / Math.sqrt(2));
            float a = (float)(arm  / Math.sqrt(2));
            drawArm(c, cx, cy,  d,  d,  d + a,  d + a);  // top-right
            drawArm(c, cx, cy, -d,  d, -d - a,  d + a);  // top-left
            drawArm(c, cx, cy,  d, -d,  d + a, -d - a);  // bottom-right
            drawArm(c, cx, cy, -d, -d, -d - a, -d - a);  // bottom-left
        } else {
            drawArm(c, cx, cy,  gap_, 0,  arm, 0);   // right
            drawArm(c, cx, cy, -gap_, 0, -arm, 0);   // left
            drawArm(c, cx, cy, 0,  gap_, 0,  arm);   // bottom
            drawArm(c, cx, cy, 0, -gap_, 0, -arm);   // top
        }
    }

    private void drawArm(Canvas c, float cx, float cy,
                         float ox, float oy, float ex, float ey) {
        if (showOutline)
            c.drawLine(cx + ox, cy + oy, cx + ex, cy + ey, outlinePaint);
        c.drawLine(cx + ox, cy + oy, cx + ex, cy + ey, linePaint);
    }

    private void drawDotOnly(Canvas c, float cx, float cy) {
        if (showOutline)
            c.drawCircle(cx, cy, dp(dotRadius * 2.5f) + dp(outlineThickness), outlinePaint);
        c.drawCircle(cx, cy, dp(dotRadius * 2.5f), dotPaint);
    }

    private void drawCircle(Canvas c, float cx, float cy) {
        if (showOutline)
            c.drawCircle(cx, cy, dp(size), outlinePaint);
        c.drawCircle(cx, cy, dp(size), linePaint);
        if (showDot) {
            if (showOutline)
                c.drawCircle(cx, cy, dp(dotRadius) + dp(outlineThickness), outlinePaint);
            c.drawCircle(cx, cy, dp(dotRadius), dotPaint);
        }
    }

    private void drawT(Canvas c, float cx, float cy) {
        // right, left, top — no bottom arm
        float arm  = dp(size);
        float gap_ = dp(gap);
        drawArm(c, cx, cy,  gap_, 0,  arm, 0);
        drawArm(c, cx, cy, -gap_, 0, -arm, 0);
        drawArm(c, cx, cy, 0, -gap_, 0, -arm);
    }

    // ── public setters ────────────────────────────────────────────────────────
    public void setStyle(CrosshairStyle s)      { style = s;            invalidate(); }
    public void setColor(int c)                 { color = c;            refreshPaints(); invalidate(); }
    public void setSize(float s)                { size = s;             invalidate(); }
    public void setThickness(float t)           { thickness = t;        refreshPaints(); invalidate(); }
    public void setGap(float g)                 { gap = g;              invalidate(); }
    public void setDotRadius(float r)           { dotRadius = r;        invalidate(); }
    public void setShowDot(boolean b)           { showDot = b;          invalidate(); }
    public void setShowOutline(boolean b)       { showOutline = b;      invalidate(); }
    public void setOutlineThickness(float t)    { outlineThickness = t; refreshPaints(); invalidate(); }
    public void setOutlineColor(int c)          { outlineColor = c;     refreshPaints(); invalidate(); }
    public void setOpacity(float o)             { opacity = o;          refreshPaints(); invalidate(); }

    // ── public getters (for saving presets) ───────────────────────────────────
    public CrosshairStyle getStyle()     { return style;           }
    public int   getColor()              { return color;           }
    public float getSize()               { return size;            }
    public float getThickness()          { return thickness;       }
    public float getGap()                { return gap;             }
    public float getDotRadius()          { return dotRadius;       }
    public boolean isShowDot()           { return showDot;         }
    public boolean isShowOutline()       { return showOutline;     }
    public float getOutlineThickness()   { return outlineThickness;}
    public int   getOutlineColor()       { return outlineColor;    }
    public float getOpacity()            { return opacity;         }
}
