// Language: Java  |  File: MainActivity.java  |  Target: Android API 26+
// Note: editor activity — live preview + all controls; starts/stops OverlayService

package com.noob.crosshair;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.switchmaterial.SwitchMaterial;

import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    // ── ui ────────────────────────────────────────────────────────────────────
    private CrosshairView  preview;
    private SwitchMaterial swOverlay;
    private Spinner        spinStyle;
    private SeekBar        sbSize, sbThickness, sbGap,
                           sbDotRadius, sbOutlineThickness, sbOpacity;
    private TextView       tvSize, tvThickness, tvGap,
                           tvDotRadius, tvOutlineThickness, tvOpacity;
    private SwitchMaterial swDot, swOutline;
    private View           colorSwatch, outlineSwatch;
    private Button         btnSavePreset, btnLoadPreset;

    private SharedPreferences prefs;

    // color held in state
    private int currentColor        = Color.RED;
    private int currentOutlineColor = Color.BLACK;

    // ── activity ──────────────────────────────────────────────────────────────
    @Override
    protected void onCreate(Bundle s) {
        super.onCreate(s);
        setContentView(R.layout.activity_main);
        setSupportActionBar(findViewById(R.id.toolbar));

        prefs = getSharedPreferences(PrefsKeys.FILE, MODE_PRIVATE);

        bindViews();
        loadPrefsIntoUi();
        wireListeners();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // sync toggle with actual service state
        swOverlay.setChecked(prefs.getBoolean(PrefsKeys.SERVICE_RUNNING, false));
    }

    // ── bind ──────────────────────────────────────────────────────────────────
    private void bindViews() {
        preview            = findViewById(R.id.preview);
        swOverlay          = findViewById(R.id.sw_overlay);
        spinStyle          = findViewById(R.id.spin_style);
        sbSize             = findViewById(R.id.sb_size);
        sbThickness        = findViewById(R.id.sb_thickness);
        sbGap              = findViewById(R.id.sb_gap);
        sbDotRadius        = findViewById(R.id.sb_dot_radius);
        sbOutlineThickness = findViewById(R.id.sb_outline_thickness);
        sbOpacity          = findViewById(R.id.sb_opacity);
        tvSize             = findViewById(R.id.tv_size);
        tvThickness        = findViewById(R.id.tv_thickness);
        tvGap              = findViewById(R.id.tv_gap);
        tvDotRadius        = findViewById(R.id.tv_dot_radius);
        tvOutlineThickness = findViewById(R.id.tv_outline_thickness);
        tvOpacity          = findViewById(R.id.tv_opacity);
        swDot              = findViewById(R.id.sw_dot);
        swOutline          = findViewById(R.id.sw_outline);
        colorSwatch        = findViewById(R.id.color_swatch);
        outlineSwatch      = findViewById(R.id.outline_swatch);
        btnSavePreset      = findViewById(R.id.btn_save_preset);
        btnLoadPreset      = findViewById(R.id.btn_load_preset);

        // spinner adapter
        List<String> styles = Arrays.asList("CROSS", "DOT", "CIRCLE", "T_SHAPE", "X_SHAPE");
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, styles);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinStyle.setAdapter(adapter);
    }

    // ── load ──────────────────────────────────────────────────────────────────
    private void loadPrefsIntoUi() {
        currentColor        = prefs.getInt(PrefsKeys.COLOR, Color.RED);
        currentOutlineColor = prefs.getInt(PrefsKeys.OUTLINE_COLOR, Color.BLACK);

        colorSwatch.setBackgroundColor(currentColor);
        outlineSwatch.setBackgroundColor(currentOutlineColor);

        String styleName = prefs.getString(PrefsKeys.STYLE, "CROSS");
        CrosshairView.CrosshairStyle style = CrosshairView.CrosshairStyle.valueOf(styleName);
        spinStyle.setSelection(style.ordinal());

        setSeekAndLabel(sbSize,             tvSize,             prefs.getFloat(PrefsKeys.SIZE, 20f),             5f,  60f,  "Size");
        setSeekAndLabel(sbThickness,        tvThickness,        prefs.getFloat(PrefsKeys.THICKNESS, 2f),         1f,  12f,  "Thickness");
        setSeekAndLabel(sbGap,              tvGap,              prefs.getFloat(PrefsKeys.GAP, 4f),               0f,  20f,  "Gap");
        setSeekAndLabel(sbDotRadius,        tvDotRadius,        prefs.getFloat(PrefsKeys.DOT_RADIUS, 2f),        1f,  10f,  "Dot");
        setSeekAndLabel(sbOutlineThickness, tvOutlineThickness, prefs.getFloat(PrefsKeys.OUTLINE_THICKNESS, 1f), 0f,  5f,   "Outline");
        setSeekAndLabel(sbOpacity,          tvOpacity,          prefs.getFloat(PrefsKeys.OPACITY, 1f),           0.1f,1f,  "Opacity");

        swDot.setChecked(prefs.getBoolean(PrefsKeys.SHOW_DOT, true));
        swOutline.setChecked(prefs.getBoolean(PrefsKeys.SHOW_OUTLINE, true));

        applyToPreview();
    }

    // ── wire ──────────────────────────────────────────────────────────────────
    private void wireListeners() {
        swOverlay.setOnCheckedChangeListener((v, on) -> toggleService(on));

        spinStyle.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                saveAndRefresh();
            }
            public void onNothingSelected(AdapterView<?> p) {}
        });

        SeekBar.OnSeekBarChangeListener refresh = new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean u) { saveAndRefresh(); }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {}
        };

        sbSize.setOnSeekBarChangeListener(refresh);
        sbThickness.setOnSeekBarChangeListener(refresh);
        sbGap.setOnSeekBarChangeListener(refresh);
        sbDotRadius.setOnSeekBarChangeListener(refresh);
        sbOutlineThickness.setOnSeekBarChangeListener(refresh);
        sbOpacity.setOnSeekBarChangeListener(refresh);

        swDot.setOnCheckedChangeListener((v, c) -> saveAndRefresh());
        swOutline.setOnCheckedChangeListener((v, c) -> saveAndRefresh());

        colorSwatch.setOnClickListener(v ->
                showColorDialog(false));
        outlineSwatch.setOnClickListener(v ->
                showColorDialog(true));

        btnSavePreset.setOnClickListener(v -> savePreset());
        btnLoadPreset.setOnClickListener(v -> loadPresetDialog());
    }

    // ── save & apply ──────────────────────────────────────────────────────────
    private void saveAndRefresh() {
        savePrefs();
        applyToPreview();
        notifyService();
    }

    private void savePrefs() {
        prefs.edit()
            .putString(PrefsKeys.STYLE,
                    ((String) spinStyle.getSelectedItem()))
            .putInt(PrefsKeys.COLOR,              currentColor)
            .putFloat(PrefsKeys.SIZE,             seekToVal(sbSize,             5f,  60f))
            .putFloat(PrefsKeys.THICKNESS,        seekToVal(sbThickness,        1f,  12f))
            .putFloat(PrefsKeys.GAP,              seekToVal(sbGap,              0f,  20f))
            .putFloat(PrefsKeys.DOT_RADIUS,       seekToVal(sbDotRadius,        1f,  10f))
            .putFloat(PrefsKeys.OUTLINE_THICKNESS,seekToVal(sbOutlineThickness, 0f,  5f))
            .putFloat(PrefsKeys.OPACITY,          seekToVal(sbOpacity,          0.1f,1f))
            .putBoolean(PrefsKeys.SHOW_DOT,       swDot.isChecked())
            .putBoolean(PrefsKeys.SHOW_OUTLINE,   swOutline.isChecked())
            .putInt(PrefsKeys.OUTLINE_COLOR,      currentOutlineColor)
            .apply();
    }

    private void applyToPreview() {
        CrosshairView.CrosshairStyle style = CrosshairView.CrosshairStyle.valueOf(
                (String) spinStyle.getSelectedItem());

        preview.setStyle(style);
        preview.setColor(currentColor);
        preview.setSize(seekToVal(sbSize, 5f, 60f));
        preview.setThickness(seekToVal(sbThickness, 1f, 12f));
        preview.setGap(seekToVal(sbGap, 0f, 20f));
        preview.setDotRadius(seekToVal(sbDotRadius, 1f, 10f));
        preview.setOutlineThickness(seekToVal(sbOutlineThickness, 0f, 5f));
        preview.setOpacity(seekToVal(sbOpacity, 0.1f, 1f));
        preview.setShowDot(swDot.isChecked());
        preview.setShowOutline(swOutline.isChecked());
        preview.setOutlineColor(currentOutlineColor);

        updateLabels();
    }

    private void notifyService() {
        if (prefs.getBoolean(PrefsKeys.SERVICE_RUNNING, false)) {
            Intent i = new Intent(this, OverlayService.class);
            i.setAction(OverlayService.ACTION_UPDATE);
            startService(i);
        }
    }

    // ── service toggle ────────────────────────────────────────────────────────
    private void toggleService(boolean on) {
        if (on) {
            if (!Settings.canDrawOverlays(this)) {
                new AlertDialog.Builder(this)
                        .setTitle("Overlay Permission Required")
                        .setMessage("Grant 'Display over other apps' permission to show the crosshair on top of games.")
                        .setPositiveButton("Grant", (d, w) -> {
                            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                    Uri.parse("package:" + getPackageName())));
                        })
                        .setNegativeButton("Cancel", (d, w) -> swOverlay.setChecked(false))
                        .show();
                return;
            }
            savePrefs();
            startForegroundService(new Intent(this, OverlayService.class));
            prefs.edit().putBoolean(PrefsKeys.SERVICE_RUNNING, true).apply();
        } else {
            stopService(new Intent(this, OverlayService.class));
            prefs.edit().putBoolean(PrefsKeys.SERVICE_RUNNING, false).apply();
        }
    }

    // ── color dialog ──────────────────────────────────────────────────────────
    private void showColorDialog(boolean isOutline) {
        // Simple hex-input dialog — replace with a full color wheel library for production
        final EditText input = new EditText(this);
        input.setHint("#FF0000");
        input.setText(isOutline
                ? String.format("#%06X", 0xFFFFFF & currentOutlineColor)
                : String.format("#%06X", 0xFFFFFF & currentColor));

        new AlertDialog.Builder(this)
                .setTitle(isOutline ? "Outline Color (hex)" : "Crosshair Color (hex)")
                .setView(input)
                .setPositiveButton("Apply", (d, w) -> {
                    try {
                        int parsed = Color.parseColor(input.getText().toString());
                        if (isOutline) {
                            currentOutlineColor = parsed;
                            outlineSwatch.setBackgroundColor(parsed);
                        } else {
                            currentColor = parsed;
                            colorSwatch.setBackgroundColor(parsed);
                        }
                        saveAndRefresh();
                    } catch (IllegalArgumentException ignored) {
                        Toast.makeText(this, "Invalid hex color", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // ── presets ───────────────────────────────────────────────────────────────
    private static final String[] PRESET_NAMES = {"Default", "Dot Only", "Circle", "Tactical X", "Red T"};

    private void savePreset() {
        // Saves current config under a user-named slot
        final EditText nameInput = new EditText(this);
        nameInput.setHint("Preset name");
        new AlertDialog.Builder(this)
                .setTitle("Save Preset")
                .setView(nameInput)
                .setPositiveButton("Save", (d, w) -> {
                    String name = nameInput.getText().toString().trim();
                    if (name.isEmpty()) return;
                    SharedPreferences.Editor e = prefs.edit();
                    e.putString("preset_" + name + "_style",   (String) spinStyle.getSelectedItem());
                    e.putInt("preset_"   + name + "_color",    currentColor);
                    e.putFloat("preset_" + name + "_size",     seekToVal(sbSize, 5f, 60f));
                    e.putFloat("preset_" + name + "_thick",    seekToVal(sbThickness, 1f, 12f));
                    e.putFloat("preset_" + name + "_gap",      seekToVal(sbGap, 0f, 20f));
                    e.putFloat("preset_" + name + "_dot_r",    seekToVal(sbDotRadius, 1f, 10f));
                    e.putFloat("preset_" + name + "_out_t",    seekToVal(sbOutlineThickness, 0f, 5f));
                    e.putFloat("preset_" + name + "_opacity",  seekToVal(sbOpacity, 0.1f, 1f));
                    e.putBoolean("preset_" + name + "_sdot",   swDot.isChecked());
                    e.putBoolean("preset_" + name + "_sout",   swOutline.isChecked());
                    e.putInt("preset_"   + name + "_out_col",  currentOutlineColor);
                    // store name in list
                    String existing = prefs.getString("preset_list", "");
                    if (!existing.contains(name)) {
                        e.putString("preset_list", existing.isEmpty() ? name : existing + "," + name);
                    }
                    e.apply();
                    Toast.makeText(this, "Preset "" + name + "" saved", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void loadPresetDialog() {
        String listStr = prefs.getString("preset_list", "");
        if (listStr.isEmpty()) {
            Toast.makeText(this, "No saved presets", Toast.LENGTH_SHORT).show();
            return;
        }
        String[] names = listStr.split(",");
        new AlertDialog.Builder(this)
                .setTitle("Load Preset")
                .setItems(names, (d, which) -> loadPreset(names[which]))
                .show();
    }

    private void loadPreset(String name) {
        currentColor        = prefs.getInt("preset_" + name + "_color",   Color.RED);
        currentOutlineColor = prefs.getInt("preset_" + name + "_out_col", Color.BLACK);
        colorSwatch.setBackgroundColor(currentColor);
        outlineSwatch.setBackgroundColor(currentOutlineColor);

        String style = prefs.getString("preset_" + name + "_style", "CROSS");
        spinStyle.setSelection(CrosshairView.CrosshairStyle.valueOf(style).ordinal());

        setSeekAndLabel(sbSize,             tvSize,             prefs.getFloat("preset_" + name + "_size",    20f), 5f,   60f,  "Size");
        setSeekAndLabel(sbThickness,        tvThickness,        prefs.getFloat("preset_" + name + "_thick",   2f),  1f,   12f,  "Thickness");
        setSeekAndLabel(sbGap,              tvGap,              prefs.getFloat("preset_" + name + "_gap",     4f),  0f,   20f,  "Gap");
        setSeekAndLabel(sbDotRadius,        tvDotRadius,        prefs.getFloat("preset_" + name + "_dot_r",   2f),  1f,   10f,  "Dot");
        setSeekAndLabel(sbOutlineThickness, tvOutlineThickness, prefs.getFloat("preset_" + name + "_out_t",   1f),  0f,   5f,   "Outline");
        setSeekAndLabel(sbOpacity,          tvOpacity,          prefs.getFloat("preset_" + name + "_opacity", 1f),  0.1f, 1f,   "Opacity");

        swDot.setChecked(prefs.getBoolean("preset_" + name + "_sdot",  true));
        swOutline.setChecked(prefs.getBoolean("preset_" + name + "_sout", true));

        saveAndRefresh();
    }

    // ── seek helpers ──────────────────────────────────────────────────────────
    private void setSeekAndLabel(SeekBar sb, TextView tv,
                                  float val, float min, float max, String label) {
        sb.setMax(100);
        int progress = (int)(((val - min) / (max - min)) * 100);
        sb.setProgress(Math.max(0, Math.min(100, progress)));
        tv.setText(String.format("%s: %.1f", label, val));
    }

    private float seekToVal(SeekBar sb, float min, float max) {
        return min + (sb.getProgress() / 100f) * (max - min);
    }

    private void updateLabels() {
        tvSize.setText(String.format("Size: %.1f",           seekToVal(sbSize,             5f,   60f)));
        tvThickness.setText(String.format("Thickness: %.1f", seekToVal(sbThickness,        1f,   12f)));
        tvGap.setText(String.format("Gap: %.1f",             seekToVal(sbGap,              0f,   20f)));
        tvDotRadius.setText(String.format("Dot: %.1f",       seekToVal(sbDotRadius,        1f,   10f)));
        tvOutlineThickness.setText(String.format("Outline: %.1f",
                                                              seekToVal(sbOutlineThickness, 0f,   5f)));
        tvOpacity.setText(String.format("Opacity: %.2f",     seekToVal(sbOpacity,          0.1f, 1f)));
    }

    // ── menu (reset) ──────────────────────────────────────────────────────────
    @Override
    public boolean onCreateOptionsMenu(Menu m) {
        getMenuInflater().inflate(R.menu.main_menu, m);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_reset) {
            prefs.edit().clear().apply();
            loadPrefsIntoUi();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
