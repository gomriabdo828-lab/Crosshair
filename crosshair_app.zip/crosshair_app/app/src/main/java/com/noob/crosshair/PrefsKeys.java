// Language: Java  |  File: PrefsKeys.java
// Note: single source of truth for all SharedPreferences keys

package com.noob.crosshair;

public final class PrefsKeys {
    private PrefsKeys() {}

    public static final String FILE             = "crosshair_prefs";
    public static final String STYLE            = "style";
    public static final String COLOR            = "color";
    public static final String SIZE             = "size";
    public static final String THICKNESS        = "thickness";
    public static final String GAP              = "gap";
    public static final String DOT_RADIUS       = "dot_radius";
    public static final String SHOW_DOT         = "show_dot";
    public static final String SHOW_OUTLINE     = "show_outline";
    public static final String OUTLINE_THICKNESS= "outline_thickness";
    public static final String OUTLINE_COLOR    = "outline_color";
    public static final String OPACITY          = "opacity";
    public static final String SERVICE_RUNNING  = "service_running";
}
