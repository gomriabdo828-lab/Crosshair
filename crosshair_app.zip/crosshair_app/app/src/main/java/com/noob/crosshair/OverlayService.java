// Language: Java  |  File: OverlayService.java  |  Target: Android API 26+
// Note: Foreground service — renders CrosshairView as a system-window overlay

package com.noob.crosshair;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.IBinder;
import android.view.Gravity;
import android.view.WindowManager;
import androidx.core.app.NotificationCompat;

public class OverlayService extends Service {

    public static final String ACTION_UPDATE = "com.noob.crosshair.UPDATE";

    private static final String CH_ID     = "crosshair_service";
    private static final int    NOTIF_ID  = 1;

    private WindowManager   wm;
    private CrosshairView   view;
    private boolean         attached = false;

    // ── lifecycle ─────────────────────────────────────────────────────────────
    @Override
    public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        createNotificationChannel();
        startForeground(NOTIF_ID, buildNotification());
        attachOverlay();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_UPDATE.equals(intent.getAction())) {
            applyPrefs();
        }
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        detachOverlay();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent i) { return null; }

    // ── overlay ───────────────────────────────────────────────────────────────
    private void attachOverlay() {
        view = new CrosshairView(this);
        applyPrefs();

        int type = android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_SYSTEM_ALERT;

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.CENTER;

        wm.addView(view, params);
        attached = true;
    }

    private void detachOverlay() {
        if (attached && view != null) {
            wm.removeView(view);
            attached = false;
        }
    }

    private void applyPrefs() {
        if (view == null) return;
        SharedPreferences prefs = getSharedPreferences(PrefsKeys.FILE, MODE_PRIVATE);

        String styleName = prefs.getString(PrefsKeys.STYLE, CrosshairView.CrosshairStyle.CROSS.name());
        view.setStyle(CrosshairView.CrosshairStyle.valueOf(styleName));
        view.setColor(prefs.getInt(PrefsKeys.COLOR, Color.RED));
        view.setSize(prefs.getFloat(PrefsKeys.SIZE, 20f));
        view.setThickness(prefs.getFloat(PrefsKeys.THICKNESS, 2f));
        view.setGap(prefs.getFloat(PrefsKeys.GAP, 4f));
        view.setDotRadius(prefs.getFloat(PrefsKeys.DOT_RADIUS, 2f));
        view.setShowDot(prefs.getBoolean(PrefsKeys.SHOW_DOT, true));
        view.setShowOutline(prefs.getBoolean(PrefsKeys.SHOW_OUTLINE, true));
        view.setOutlineThickness(prefs.getFloat(PrefsKeys.OUTLINE_THICKNESS, 1f));
        view.setOutlineColor(prefs.getInt(PrefsKeys.OUTLINE_COLOR, Color.BLACK));
        view.setOpacity(prefs.getFloat(PrefsKeys.OPACITY, 1f));
    }

    // ── notification ──────────────────────────────────────────────────────────
    private void createNotificationChannel() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(
                    CH_ID, "Crosshair Overlay", NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("Keeps the crosshair visible");
            getSystemService(NotificationManager.class).createNotificationChannel(ch);
        }
    }

    private Notification buildNotification() {
        Intent stop = new Intent(this, OverlayService.class);
        stop.setAction("STOP");
        // Tap notification → open main activity
        Intent open = new Intent(this, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        return new NotificationCompat.Builder(this, CH_ID)
                .setContentTitle("Crosshair Active")
                .setContentText("Tap to edit • always on top")
                .setSmallIcon(android.R.drawable.ic_menu_crosshairs)
                .setContentIntent(pi)
                .setOngoing(true)
                .setSilent(true)
                .build();
    }
}
